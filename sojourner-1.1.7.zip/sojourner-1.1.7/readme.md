# Sojouner
 ![license](https://img.shields.io/badge/license-GPL_v3-green.svg?style=flat-square)
 ![platform](https://img.shields.io/badge/platform-OS_X 10.11+-lightgrey.svg?style=flat-square)
 ![platform](https://img.shields.io/badge/platform-Ubuntu_14.04_| 16.04-orange.svg?style=flat-square)
 ![platform](https://img.shields.io/badge/windows-8_| 10-6cdbea.svg?style=flat-square)
 ![python version](https://img.shields.io/badge/python-2.7-blue.svg?style=flat-square)

A lazy attempt at beating NASA at their own game.

### Current Version: ![current version](https://img.shields.io/badge/version-1.1.7-green.svg?style=flat-square)

Check the [Wiki](https://github.com/markwatneyy/Sojourner/wiki) Page for more info
